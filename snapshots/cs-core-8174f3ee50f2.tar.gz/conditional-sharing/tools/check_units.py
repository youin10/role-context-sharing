"""Small checks with independently written expectations for parts the scenario runs do not exercise:
type-file loading errors (cycle, undeclared class), and the aligned oracle condition evaluation
(oracle/core.py holds with the instance under the key and class conditions).

  python tools/check_units.py <out.json>
"""
import json, os, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from arms.d.ontology import load_types  # noqa: E402
from oracle.core import holds  # noqa: E402

NS = "http://ai.uos.ac.kr/logistics-ontology#"
HEAD = "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n@prefix : <%s> .\n" % NS
rows = []


def case(cid, fn, expected):
    try:
        got = fn()
    except Exception as e:
        got = f"error:{type(e).__name__}"
    rows.append({"id": cid, "expected": expected, "observed": got, "pass": got == expected})


def types_from(text):
    with tempfile.NamedTemporaryFile("w", suffix=".ttl", delete=False) as f:
        f.write(HEAD + text)
    try:
        t = load_types(f.name)
        return sorted(c[len(NS):] for c in t.types_of("x1")) if "x1" in t.individuals else "loaded"
    finally:
        os.unlink(f.name)


case("U01 subClassOf cycle refused", lambda: types_from(":A a rdfs:Class ; rdfs:subClassOf :B .\n:B a rdfs:Class ; rdfs:subClassOf :A .\n"), "error:ValueError")
case("U02 undeclared class of an individual refused", lambda: types_from(":A a rdfs:Class .\n:x1 a :Nope .\n"), "error:ValueError")
case("U03 transitive membership", lambda: types_from(":A a rdfs:Class .\n:B a rdfs:Class ; rdfs:subClassOf :A .\n:C a rdfs:Class ; rdfs:subClassOf :B .\n:x1 a :C .\n"), ["A", "B", "C"])
case("U04 multiple membership is a union", lambda: types_from(":A a rdfs:Class .\n:B a rdfs:Class .\n:x1 a :A , :B .\n"), ["A", "B"])

T = load_types(os.path.join(ROOT, "inputs/ontology/logistics-classes.ttl"), os.path.join(ROOT, "inputs/ontology/logistics-individuals.ttl"))
W = [{"field": "robot", "op": "isa", "value": NS + "Biped"}, {"field": "battery", "op": "<=", "value": 30}]
case("U05 oracle holds: humanoid1 30 under Biped<=30 (key visible)", lambda: holds(W, {"battery": 30}, "humanoid1", "robot", T), True)
case("U06 oracle holds: diff1 25 under Biped<=30", lambda: holds(W, {"battery": 25}, "diff1", "robot", T), False)
case("U07 oracle holds: identity on the key", lambda: holds([{"field": "robot", "op": "=", "value": "biped1"}], {"battery": 1}, "biped1", "robot", T), True)
case("U08 oracle holds without key keeps the old value-only behaviour", lambda: holds([{"field": "battery", "op": "<", "value": 30}], {"battery": 29}), True)
case("U09 oracle holds: !isa on a registered non-Biped", lambda: holds([{"field": "robot", "op": "!isa", "value": NS + "Biped"}], {"battery": 1}, "wheeled1", "robot", T), True)
case("U10 oracle holds: unregistered individual is not treated as a value", lambda: holds([{"field": "robot", "op": "!isa", "value": NS + "Biped"}], {"battery": 1}, "ghost9", "robot", T), "error:KeyError")
json.dump(rows, open(sys.argv[1], "w"), indent=1)
for r in rows:
    print("PASS" if r["pass"] else "FAIL", r["id"], r["observed"])
sys.exit(0 if all(r["pass"] for r in rows) else 1)
